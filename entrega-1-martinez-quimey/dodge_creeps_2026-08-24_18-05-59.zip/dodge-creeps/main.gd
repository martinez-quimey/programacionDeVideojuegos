extends Node

@export var mob_scene: PackedScene
@export var mobGrande_scene: PackedScene
var score

func _ready():
	$HUD.start_game.connect(new_game)
func gameOveer() -> void:
	$ScoreTimer.stop()
	$MobTimer.stop()
	$HUD.show_game_over()

func new_game():
	get_tree().call_group("mobs", "queue_free")
	get_tree().call_group("mobsGrandes", "queue_free")
	score = 0
	$player.start($StartPosition.position)
	$StartTimer.start()
	$HUD.update_score(score)
	$HUD.show_message("Get Ready")
	

func _on_mob_timer_timeout():
	print("¡¡SE CREÓ UN MOB !!")
	# Create a new instance of the Mob scene.
	var mob = mob_scene.instantiate()

	# Choose a random location on Path2D.
	var mob_spawn_location = $MobPath/MobSpawnLocation
	mob_spawn_location.progress_ratio = randf()

	# Set the mob's position to the random location.
	mob.position = mob_spawn_location.position

	# Set the mob's direction perpendicular to the path direction.
	var direction = mob_spawn_location.rotation + PI / 2

	# Add some randomness to the direction.
	direction += randf_range(-PI / 4, PI / 4)
	mob.rotation = direction

	# Choose the velocity for the mob.
	var velocity = Vector2(randf_range(150.0, 250.0), 0.0)
	mob.linear_velocity = velocity.rotated(direction)

	# Spawn the mob by adding it to the Main scene.
	add_child(mob)

func _on_score_timer_timeout():
	score += 1
	$HUD.update_score(score)

func _on_start_timer_timeout():
	$MobTimer.start()
	$MobGrandeTimer.start()
	
	$ScoreTimer.start()


func _on_mob_grande_timer_timeout() -> void:
	print("¡¡SE CREÓ UN MOB GRANDE!!")
		# Create a new instance of the Mob scene.
	var mobGrande = mobGrande_scene.instantiate()

	# Choose a random location on Path2D.
	var mobGrande_spawn_location = $MobPath/MobSpawnLocation
	mobGrande_spawn_location.progress_ratio = randf()

	# Set the mob's position to the random location.
	mobGrande.position = mobGrande_spawn_location.position

	# Set the mob's direction perpendicular to the path direction.
	var direction = mobGrande_spawn_location.rotation + PI / 2

	# Add some randomness to the direction.
	direction += randf_range(-PI / 4, PI / 4)
	mobGrande.rotation = direction

	# Choose the velocity for the mob.
	var velocity = Vector2(randf_range(150.0, 250.0), 0.0)
	mobGrande.linear_velocity = velocity.rotated(direction)

	# Spawn the mob by adding it to the Main scene.
	add_child(mobGrande)
