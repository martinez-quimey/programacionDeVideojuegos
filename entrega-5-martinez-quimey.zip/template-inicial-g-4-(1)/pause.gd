extends CanvasLayer


signal return_pressed
@export var mouse_cursor: Texture

@export var mainMenu: PackedScene

func _ready() -> void:
	$OptionsMenu.hide()
	Input.set_custom_mouse_cursor(mouse_cursor)


func _on_options_button_pressed() -> void:
	print("presionado el options")
	$OptionsMenu.show()




func _on_continuar_button_pressed() -> void:
	get_tree().paused = true
	self.hide()




func _on_options_menu_return_pressed() -> void:
	emit_signal("return_pressed")


func _on_return_pressed() -> void:
	$OptionsMenu.hide()
