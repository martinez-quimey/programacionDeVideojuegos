extends Node

@export var level_manager_scene: PackedScene
@export var mouse_cursor: Texture


func _ready() -> void:
	$OptionsMenu.hide()
	Input.set_custom_mouse_cursor(mouse_cursor)


func _on_options_button_pressed() -> void:
	print("presionado el options")
	$OptionsMenu.show()


func _on_start_button_pressed() -> void:
	get_tree().change_scene_to_packed(level_manager_scene)


func _on_exit_button_pressed() -> void:
	get_tree().quit()



func _on_options_menu_return_pressed() -> void:
	$OptionsMenu.hide()
