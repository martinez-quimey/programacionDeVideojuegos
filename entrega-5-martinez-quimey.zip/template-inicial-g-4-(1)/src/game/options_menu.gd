extends CanvasLayer

signal return_pressed


func _on_return_button_pressed() -> void:
	print ("boton presionado")
	emit_signal("return_pressed")
