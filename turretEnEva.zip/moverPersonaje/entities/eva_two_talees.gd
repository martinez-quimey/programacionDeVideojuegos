#Player
extends CharacterBody2D


signal hit

@export var speed: float = 400.0
var screen_size: Vector2


func _ready() -> void:
	screen_size = get_viewport_rect().size
	hide()


func _process(delta: float) -> void:
	var velocity := Vector2.ZERO

	# Movimiento
	if Input.is_action_pressed("derecha"):
		velocity.x += 1
	if Input.is_action_pressed("izquierda"):
		velocity.x -= 1

	# Animación y velocidad
	if velocity.length() > 0:
		velocity = velocity.normalized() * speed
		$AnimatedSprite2D.play()
	else:
		$AnimatedSprite2D.stop()

	# Mover al jugador
	position += velocity * delta

	# Mantener al jugador dentro de la pantalla
	position = position.clamp(Vector2.ZERO, screen_size)

	# Animación según la dirección
	if velocity.x != 0:
		$AnimatedSprite2D.animation = "caminar"
		$AnimatedSprite2D.flip_h = velocity.x < 0
		$AnimatedSprite2D.flip_v = false
	else:
		$AnimatedSprite2D.animation = "quieta"
		$AnimatedSprite2D.flip_v = false


func _on_body_entered(body: Node2D) -> void:
	hide()
	hit.emit()
	$CollisionShape2D.set_deferred("disabled", true)


func start(pos: Vector2) -> void:
	position = pos
	show()
	$CollisionShape2D.set_deferred("disabled", false)
