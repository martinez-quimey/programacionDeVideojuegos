
extends CharacterBody2D
class_name EnemyTurret

signal hit(amount: int)
signal hp_changed(hp, max_hp)

@onready var fire_position: Node2D = $FirePosition
@onready var raycast: RayCast2D = $RayCast2D
@onready var body_anim: AnimatedSprite2D = $Body
@onready var hp_progress: ProgressBar = $HpProgress
@onready var sonidos: AudioStreamPlayer2D = $Sonidos

@export var projectile_scene: PackedScene
@export var pathfinding: PathfindAstar

@export var sonido_disparo: AudioStream
@export var sonido_grito: AudioStream
@export var sonido_muerte: AudioStream

@export var intervalo_grito_min: float = 5.0
@export var intervalo_grito_max: float = 12.0

var target: Node2D
var _projectile_container: Node

@export var max_hp: int = 5
var hp: int = max_hp

var dead: bool = false


func _ready() -> void:
	hp_progress.max_value = max_hp
	hp_progress.value = hp
	hp_progress.modulate = Color.TRANSPARENT

	_programar_grito()


func initialize(turret_pos: Vector2, projectile_container: Node) -> void:
	global_position = turret_pos
	self._projectile_container = projectile_container


func _fire() -> void:
	if target != null:
		var proj_instance: Node = projectile_scene.instantiate()
		if _projectile_container == null:
			_projectile_container = get_parent()

		_projectile_container.add_child(proj_instance)
		proj_instance.initialize(
			fire_position.global_position,
			fire_position.global_position.direction_to(target.global_position)
		)

		_reproducir_sonido(sonido_disparo)


func _programar_grito() -> void:
	if dead:
		return

	var espera := randf_range(intervalo_grito_min, intervalo_grito_max)
	await get_tree().create_timer(espera).timeout

	if dead or not is_inside_tree():
		return

	_reproducir_sonido(sonido_grito)
	_programar_grito()


func _reproducir_sonido(sonido: AudioStream) -> void:
	if sonido == null:
		return

	sonidos.stop()
	sonidos.stream = sonido
	sonidos.play()


func _can_see_target() -> bool:
	if target == null:
		return false

	raycast.target_position = raycast.to_local(target.global_position)
	raycast.force_raycast_update()
	return raycast.is_colliding() and raycast.get_collider() == target


func _look_at_target() -> void:
	body_anim.flip_h = raycast.target_position.x < 0


func notify_hit(amount: int = 1) -> void:
	hit.emit(amount)


var hp_tween: Tween


func _sum_hp(amount: int) -> void:
	hp = clampi(hp + amount, 0, max_hp)
	hp_progress.max_value = max_hp
	hp_progress.value = hp
	hp_changed.emit(hp, max_hp)

	if hp_tween:
		hp_tween.kill()

	hp_tween = create_tween()
	hp_progress.modulate = Color.WHITE
	hp_tween.tween_property(
		hp_progress, "modulate", Color.TRANSPARENT, 5.0
	)


func _remove() -> void:
	if dead:
		return

	dead = true
	_reproducir_sonido(sonido_muerte)

	# Espera a que termine el sonido antes de eliminar al enemigo.
	if sonido_muerte != null:
		await sonidos.finished

	if not is_inside_tree():
		return

	get_parent().remove_child(self)
	queue_free()


func _play_animation(animation: String) -> void:
	if body_anim.sprite_frames.has_animation(animation):
		body_anim.play(animation)


func get_current_animation() -> String:
	return body_anim.animation
